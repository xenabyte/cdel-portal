

<!-- Main Content -->
<?php $__env->startSection('content'); ?>
<div class="col-lg-8">
    <div class="p-lg-5 p-4">
        <div>
            <h5 class="text-primary">Welcome Back !</h5>
            <p class="text-muted">Reset Portal</p>
        </div>

        <div class="mt-2 text-center">
            <lord-icon
                src="https://cdn.lordicon.com/rhvddzym.json" trigger="loop" colors="primary:#0ab39c" class="avatar-xl">
            </lord-icon>
        </div>

        <div class="mt-4">
            <form method="POST" action="<?php echo e(url('/staff/password/email')); ?>">
                <?php echo csrf_field(); ?>

                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <div class="mb-3" class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" class="form-control" name="email" id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>" autofocus>

                    <?php if($errors->has('email')): ?>
                        <br>
                        <div class="alert alert-danger" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mt-4">
                    <button class="btn btn-success w-100" type="submit">Send Password Reset Link</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('staff.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/koderiang/WebProjects/TAU/tau_portal/resources/views/staff/auth/passwords/email.blade.php ENDPATH**/ ?>