

<?php $__env->startSection('content'); ?>
<div class="col-lg-8">
    <div class="p-lg-5 p-4">
        <div>
            <h5 class="text-primary">Welcome Back !</h5>
            <p class="text-muted">Sign in to continue to Guardian Portal.</p>
        </div>

        <div class="mt-4">
            <form method="POST" action="<?php echo e(url('/guardian/login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3" class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" class="form-control" name="email" id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>" autofocus>

                    <?php if($errors->has('email')): ?>
                        <br>
                        <div class="alert alert-danger" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>



                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> mb-3">
                    <div class="float-end">
                        <a href="<?php echo e(url('/guardian/password/reset')); ?>" class="text-muted">Forgot password?</a>
                    </div>
                    <label class="form-label" for="password-input">Password</label>
                    <div class="position-relative auth-pass-inputgroup mb-3">
                        <input type="password" class="form-control pe-5 password-input" name="password" placeholder="Enter password" id="password-input">
                        <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon" type="button" id="password-addon"><i class="ri-eye-fill align-middle"></i></button>
                    </div>


                    <?php if($errors->has('password')): ?>
                        <br>
                        <div class="alert alert-danger" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="auth-remember-check">
                    <label class="form-check-label" for="auth-remember-check">Remember me</label>
                </div>

                <div class="mt-4">
                    <button class="btn btn-success w-100" type="submit">Sign In</button>
                </div>
            </form>
        </div>

        <!-- <div class="mt-5 text-center">
            <p class="mb-0">Don't have an account ? <a href="<?php echo e(url('/guardian/register')); ?>" class="fw-semibold text-primary text-decoration-underline"> Signup</a> </p>
        </div> -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guardian.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/koderiang/WebProjects/TAU/tau_portal/resources/views/guardian/auth/login.blade.php ENDPATH**/ ?>