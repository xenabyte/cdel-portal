

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Student Results</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
                    <li class="breadcrumb-item active">Student Results</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->
<?php if(empty($students)): ?>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <div class="row justify-content-center">
                        <div class="col-lg-9">
                            <h4 class="mt-4 fw-semibold">Fetch Examination result</h4>
                            <p class="text-muted mt-3"></p>
                            <div class="mt-4">
                                <form action="<?php echo e(url('/admin/generateStudentResults')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row g-3">

                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="faculty" name="faculty_id" aria-label="faculty" onchange="handleFacultyChange(event)">
                                                    <option value="" selected>--Select--</option>
                                                    <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($faculty->id); ?>"><?php echo e($faculty->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="faculty">Faculty</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="department" name="department_id" aria-label="department" onchange="handleDepartmentChange(event)">
                                                    <option value="" selected>--Select--</option>
                                                </select>
                                                <label for="department">Department</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="programme" name="programme_id" aria-label="programme">
                                                    <option value="" selected>--Select--</option>
                                                </select>
                                                <label for="department">Programme</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="level" name="level_id" aria-label="level">
                                                    <option value="" selected>--Select--</option>
                                                    <?php $__currentLoopData = $academicLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academicLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($academicLevel->id); ?>"><?php echo e($academicLevel->level); ?> Level</option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="level">Academic Level</label>
                                            </div>
                                        </div>
        
                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="semester" name="semester" aria-label="semester">
                                                    <option value="" selected>--Select--</option>
                                                    <option value="1">First Semester</option>
                                                    <option value="2">Second Semester</option>
                                                </select>
                                                <label for="semester">Semester</label>
                                            </div>
                                        </div>
        
        
                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="session" name="session" aria-label="Academic Session">
                                                    <option value="" selected>--Select--</option>
                                                    <?php $__currentLoopData = $academicSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($session->year); ?>"><?php echo e($session->year); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="session">Academic Session</label>
                                            </div>
                                        </div>

                                        <button type="submit" id="submit-button" class="btn btn-fill btn-primary btn-lg btn-block mb-5">Get Results</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end card-->
    </div>
    <!--end col-->
</div>
<?php endif; ?>

<?php if(!empty($students)): ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Result(s) for <?php echo e($academiclevel->level); ?> Level,  <?php echo e(!empty($programme)?$programme->name:null); ?> for <?php echo e($academicSession); ?> Academic Session</h4>
                <div class="flex-shrink-0">
                    <?php if(!empty($programme)): ?>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#approveResult">Approve Result(s)</button>
                    <?php endif; ?>
                </div>
            </div><!-- end card header -->

            <div id="approveResult" class="modal fade" tabindex="-1" aria-hidden="true" style="display: none;">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body text-center p-5">
                            <div class="text-end">
                                <button type="button" class="btn-close text-end" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="mt-2">
                                <lord-icon src="https://cdn.lordicon.com/xxdqfhbi.json" trigger="hover" style="width:150px;height:150px">
                                </lord-icon>
                                <h4 class="mb-3 mt-4">Are you sure you want to approve result for <br><?php echo e($academiclevel->level); ?> level <?php echo e(!empty($programme)?$programme->name:null); ?>?</h4>
                                <form action="<?php echo e(url('/admin/approveResult')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentforIds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="student_ids[]" value="<?php echo e($studentforIds->id); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($programme)): ?>
                                    <input type="hidden" name="level_id" value="<?php echo e($academiclevel->id); ?>">
                                    <input type="hidden" name="programme_id" value="<?php echo e($programme->id); ?>">
                                    <input type="hidden" name="department_id" value="<?php echo e($department_id); ?>">
                                    <input type="hidden" name="faculty_id" value="<?php echo e($faculty_id); ?>">
                                    <input type="hidden" name="session" value="<?php echo e($academicSession); ?>">
                                    <?php endif; ?>
                                    <hr>
                                    <button type="submit" id="submit-button" class="btn btn-success w-100">Yes, Approve</button>
                                </form>
                            </div>
                        </div>
                        <div class="modal-footer bg-light p-3 justify-content-center">

                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->

            <div class="card-body table-responsive">
                <!-- Bordered Tables -->

                <table id="buttons-datatables" class="display table table-bordered table-striped p-3" style="width:100%">
                    <thead>
                        <tr>
                            <th>SN</th>
                            <th>Student Name</th>
                            <th>Matric Number</th>
                            <th>Degree Class</th>
                            <th>Standing</th>
                            <th>No of failed course</th>
                            <th>Total failed unit</th>
                            <th>Failed courses</th>
                            <th>Previous Total Credit Units</th>
                            <th>Previous Total Credit Points</th>
                            <th>Previous CGPA</th>
                            <th class="bg bg-primary text-light">Current Total Credit Units</th>
                            <th class="bg bg-primary text-light">Current Total Credit Points</th>
                            <th class="bg bg-primary text-light">Current GPA</th>
                            <th>Cumulative Total Credit Units</th>
                            <th>Cumulative Total Credit Points</th>
                            <th>Cumulative CGPA</th>
                            <th style=""><?php echo e($semester == 1 ? 'First' : 'Second'); ?> Semester Courses</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $degreeClass = new \App\Models\DegreeClass;

                            $semesterRegisteredCourses = $student->registeredCourses->where('semester', $semester)->where('level_id', $academiclevel->id)->where('academic_session', $academicSession);
                            $currentRegisteredCreditUnits =  $semesterRegisteredCourses->sum('course_credit_unit');
                            $currentRegisteredGradePoints = $semesterRegisteredCourses->sum('points');
                            $currentGPA = $currentRegisteredGradePoints > 0 ? number_format($currentRegisteredGradePoints / $currentRegisteredCreditUnits, 2) : 0;
                            $failedSemesterCourses = $semesterRegisteredCourses->where('grade', 'F');

                            $allRegisteredCourses = $student->registeredCourses->where('grade', '!=', null);
                            $allRegisteredCreditUnits =  $allRegisteredCourses->sum('course_credit_unit');
                            $allRegisteredGradePoints = $allRegisteredCourses->sum('points');
                            $CGPA = $allRegisteredGradePoints > 0 ? number_format($allRegisteredGradePoints / $allRegisteredCreditUnits, 2) : 0;

                            $prevRegisteredCourses = $student->registeredCourses->where('semester', '!=', $semester)->where('level_id', '!=', $academiclevel->id);
                            $prevRegisteredCreditUnits =  $prevRegisteredCourses->sum('course_credit_unit');
                            $prevRegisteredGradePoints = $prevRegisteredCourses->sum('points');
                            if ($prevRegisteredCreditUnits != 0) {
                                $prevCGPA = number_format($prevRegisteredGradePoints / $prevRegisteredCreditUnits, 2);
                            } else {
                                $prevCGPA = 0.00; // Set a default value or handle the situation accordingly
                            }

                            $classGrade = $degreeClass->computeClass($CGPA);
                            $class = $classGrade->degree_class;
                            $standing = $classGrade->id > 3? 'NGS' : 'GS'; 
                            
                        ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(strtoupper($student->applicant->lastname).', '.$student->applicant->othernames); ?></td>
                                <td><?php echo e($student->matric_number); ?></td>
                                <td><?php echo e($class); ?></td>
                                <td><?php echo e($standing); ?></td>
                                <td class="text-danger"><?php echo e($failedSemesterCourses->count()); ?></td>
                                <td class="text-danger"><?php echo e($failedSemesterCourses->sum('course_credit_unit')); ?></td>
                                <td>
                                    <?php if($failedSemesterCourses->count() > 0): ?>
                                        <span class="text-danger">
                                            <?php $__currentLoopData = $failedSemesterCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $failedSemesterCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($failedSemesterCourse->course_code); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                    <?php endif; ?>    
                                </td>
                                <td><?php echo e($prevRegisteredCreditUnits); ?></td>
                                <td><?php echo e($prevRegisteredGradePoints); ?></td>
                                <td><?php echo e($prevCGPA); ?></td>
                                <td class="bg bg-soft-primary"><?php echo e($currentRegisteredCreditUnits); ?></td>
                                <td class="bg bg-soft-primary"><?php echo e($currentRegisteredGradePoints); ?></td>
                                <td class="bg bg-soft-primary"><?php echo e($currentGPA); ?></td>
                                <td><?php echo e($allRegisteredCreditUnits); ?></td>
                                <td><?php echo e($allRegisteredGradePoints); ?></td>
                                <td><?php echo e($CGPA); ?></td>
                                <td width="200px">
                                    <div class="accordion" id="default-accordion-example">
                                        <div class="accordion-item shadow">
                                            <h2 class="accordion-header" id="headingTwo">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#studentCourses<?php echo e($student->id); ?>" aria-expanded="false" aria-controls="studentCourses">
                                                    View Courses
                                                </button>
                                            </h2>
                                            <div id="studentCourses<?php echo e($student->id); ?>" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#default-accordion-example">
                                                <div class="accordion-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped">
                                                            <thead>
                                                            <tr>
                                                                <th>SN</th>
                                                                <th>Code</th>
                                                                <th>Course Title</th>
                                                                <th>Unit</th>
                                                                <th>Total Score</th>
                                                                <th>Grade</th>
                                                                <th>Point</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $semesterRegisteredCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registeredCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($loop->iteration); ?></td>
                                                                        <td><?php echo e($registeredCourse->course->code); ?></td>
                                                                        <td><?php echo e($registeredCourse->course->name); ?></td>
                                                                        <td><?php echo e($registeredCourse->course_credit_unit); ?></td>
                                                                        <td><?php echo e($registeredCourse->total); ?></td>
                                                                        <td><?php echo e($registeredCourse->grade); ?></td>
                                                                        <td><?php echo e($registeredCourse->points); ?></td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                
            </div>
        </div><!-- end card -->
    </div>
    <!-- end col -->
</div>
<!-- end row -->
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/koderiang/WebProjects/TAU/tau_portal/resources/views/admin/getStudentResults.blade.php ENDPATH**/ ?>