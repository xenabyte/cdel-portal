

<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Applicant</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
                    <li class="breadcrumb-item active">Applicant</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="row gx-lg-5">
                    <div class="col-xl-4 col-md-8 mx-auto">
                        <div class="product-img-slider">
                            <div class="swiper product-thumbnail-slider p-2 rounded bg-light">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <img src="<?php echo e(asset($applicant->image)); ?>" alt="" class="img-fluid d-block" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <h4 class="mt-3 alert alert-info">Admission Status: <?php echo e(empty($applicant->status)? 'Processing' : ucwords($applicant->status)); ?></h4>
                        <br>
                    </div>
                    <!-- end col -->

                    <div class="col-xl-8">
                        <div class="mt-xl-0 mt-5">
                            <div class="d-flex">
                                <div class="flex-grow-1">
                                    <h4><?php echo e($applicant->lastname .' '. $applicant->othernames); ?></h4>
                                    <div class="hstack gap-3 flex-wrap">
                                        <div><a href="#" class="text-primary d-block"><?php echo e($applicant->programme->name); ?></a></div>
                                        <div class="vr"></div>
                                        <div class="text-muted">Application ID : <span class="text-body fw-medium"> <?php echo e($applicant->application_number); ?></span></div>
                                        <?php if($applicant->application_type == 'UTME'): ?>
                                        <div class="vr"></div>
                                        <div class="text-muted">UTME Scores : <span class="text-body fw-medium"> <?php echo e($applicant->utmes->sum('score')); ?></span></div>
                                        <?php endif; ?>
                                        <div class="vr"></div>
                                        <div class="text-muted">Application Date : <span class="text-body fw-medium"><?php echo e($applicant->updated_at); ?></span></div>
                                    </div>
                                </div>
                                <div class="flex-shrink-0">
                                    <div>
                                    </div>
                                </div>
                            </div>

                            <div class="product-content mt-5">
                                <h5 class="fs-14 mb-3"> Applicant Information</h5>
                                <nav>
                                    <ul class="nav nav-tabs nav-tabs-custom nav-info" id="nav-tab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="nav-speci-tab" data-bs-toggle="tab" href="#biodata" role="tab" aria-controls="nav-speci" aria-selected="true">Bio Data</a>
                                        </li>
                                        
                                        <li class="nav-item">
                                            <a class="nav-link" id="nav-detail-tab" data-bs-toggle="tab" href="#olevel" role="tab" aria-controls="nav-detail" aria-selected="false">Olevel Result</a>
                                        </li>
                                        <?php if($applicant->application_type == 'UTME'): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" id="nav-detail-tab" data-bs-toggle="tab" href="#utme" role="tab" aria-controls="nav-detail" aria-selected="false">UTME Result</a>
                                        </li>
                                        <?php endif; ?>

                                        <?php if($applicant->application_type == 'DE'): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" id="nav-detail-tab" data-bs-toggle="tab" href="#de" role="tab" aria-controls="nav-detail" aria-selected="false">Direct Entry Result</a>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                                <div class="tab-content border border-top-0 p-4" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="biodata" role="tabpanel" aria-labelledby="nav-speci-tab">
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <tbody>
                                                    <tr>
                                                        <th scope="row" style="width: 200px;">Fullname</th>
                                                        <td><?php echo e($applicant->lastname .' '. $applicant->othernames); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Email</th>
                                                        <td><?php echo e($applicant->email); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Phone Number</th>
                                                        <td><?php echo e($applicant->phone_number); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Gender</th>
                                                        <td><?php echo e($applicant->gender); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Date of Birth</th>
                                                        <td><?php echo e($applicant->dob); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Religion</th>
                                                        <td><?php echo e($applicant->religion); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Marital Status</th>
                                                        <td><?php echo e($applicant->marital_status); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Nationality</th>
                                                        <td><?php echo e($applicant->nationality); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">State of Origin</th>
                                                        <td><?php echo e($applicant->state); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Local Government Area</th>
                                                        <td><?php echo e($applicant->lga); ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="olevel" role="tabpanel" aria-labelledby="nav-detail-tab">
                                        <div>
                                            <?php if(!empty($applicant->olevel_1)): ?>
                                            <h5 class="fs-14 mb-3"> Schools Attended</h5>
                                            <?php echo $applicant->schools_attended; ?>

                                            <hr>
                                            <div class="row mb-2">
                                                <div class="col-sm-6 col-xl-12">
                                                    <!-- Simple card -->
                                                    <i class="bx bxs-file-jpg text-danger" style="font-size: 50px"></i><span style="font-size: 20px">Olevel Result</span>
                                                    <div class="text-end">
                                                        <a href="<?php echo e(asset($applicant->olevel_1)); ?>" target="blank" class="btn btn-success">View</a>
                                                    </div>
                                                    <?php if($applicant->sitting_no > 1): ?>
                                                    <i class="bx bxs-file-jpg text-danger" style="font-size: 50px"></i><span style="font-size: 20px">Olevel Result (Second Sitting)</span>
                                                    <div class="text-end">
                                                        <a href="<?php echo e(asset($applicant->olevel_2)); ?>" target="blank"  class="btn btn-success">View</a>
                                                    </div>
                                                    <?php endif; ?>
                                                </div><!-- end col -->
                                            </div>
                                            <?php endif; ?>
                                            <hr>
                                            <table class="table table-borderedless table-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Id</th>
                                                        <th scope="col">Subject</th>
                                                        <th scope="col">Grade</th>
                                                        <th scope="col">Registration Number</th>
                                                        <th scope="col">Year</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $applicant->olevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $olevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td><?php echo e($olevel->subject); ?></td>
                                                        <td><?php echo e($olevel->grade); ?></td>
                                                        <td><?php echo e($olevel->reg_no); ?></td>
                                                        <td><?php echo e($olevel->year); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <?php if($applicant->application_type == 'UTME'): ?>
                                    <div class="tab-pane fade" id="utme" role="tabpanel" aria-labelledby="nav-detail-tab">
                                        <div>
                                            <?php if(!empty($applicant->utme)): ?>
                                            <div class="row mb-2">
                                                <div class="col-sm-6 col-xl-12">
                                                    <!-- Simple card -->
                                                    <i class="bx bxs-file-jpg text-danger" style="font-size: 50px"></i><span style="font-size: 20px">UTME Result Printout</span>
                                                    <div class="text-end">
                                                        <a href="<?php echo e(asset($applicant->utme)); ?>"  target="blank" class="btn btn-success">View</a>
                                                    </div>
                                                </div><!-- end col -->
                                            </div>
                                            <?php endif; ?>
                                            <hr>
                                            <table class="table table-borderedless table-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Id</th>
                                                        <th scope="col">Subject</th>
                                                        <th scope="col">Score</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $applicant->utmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                        <td><?php echo e($utme->subject); ?></td>
                                                        <td><?php echo e($utme->score); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row"></th>
                                                        <td>Total</td>
                                                        <td><strong><?php echo e($applicant->utmes->sum('score')); ?></strong></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($applicant->application_type == 'DE'): ?>
                                    <div class="tab-pane fade" id="de" role="tabpanel" aria-labelledby="nav-detail-tab">
                                        <div>
                                            <h5 class="fs-14 mb-3"> Institution Attended</h5>
                                            <?php echo $applicant->de_school_attended; ?>

                                            <hr>
                                            <?php if(!empty($applicant->de_result)): ?>
                                            <div class="row mb-2">
                                                <div class="col-sm-6 col-xl-12">
                                                    <!-- Simple card -->
                                                    <i class="bx bxs-file-jpg text-danger" style="font-size: 50px"></i><span style="font-size: 20px">Direct Entry Result</span>
                                                    <div class="text-end">
                                                        <a href="<?php echo e(asset($applicant->de_result)); ?>"  target="blank" class="btn btn-success">View</a>
                                                    </div>
                                                </div><!-- end col -->
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>  
                            </div>
                            <!-- product-content -->
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end card body -->
        </div>
        <!-- end card -->
    </div>
    <!-- end col -->
</div>
<!-- end row --> 


<?php $__env->stopSection(); ?>

<?php echo $__env->make('partner.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/koderiang/WebProjects/TAU/tau_portal/resources/views/partner/applicant.blade.php ENDPATH**/ ?>