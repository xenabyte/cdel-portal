<!-- Main Content -->
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6 col-xl-5">
        <div class="card mt-4">

            <div class="card-body p-4">
                <div class="text-center mt-2">
                    <h5 class="text-primary">Welcome Back !</h5>
                    <p class="text-muted">Reset Password</p>
                </div>
                <div class="p-2 mt-4">
                    <form method="POST" action="<?php echo e(url('/admin/password/email')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>"class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" name="email" class="form-control" id="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>" autofocus>

                            <?php if($errors->has('email')): ?>
                            <div class="mt-4 mb-3">
                                <span class="help-block alert alert-danger">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="mt-4">
                            <button class="btn btn-success w-100" type="submit">Send Password Reset Link</button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- end card body -->
        </div>
        <!-- end card -->

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/koderiang/WebProjects/TAU/tau_portal/resources/views/admin/auth/passwords/email.blade.php ENDPATH**/ ?>