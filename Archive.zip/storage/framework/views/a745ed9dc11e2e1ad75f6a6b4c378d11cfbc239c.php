<?php
    $student = Auth::guard('student')->user();
?>
<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Wallet Transactions</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
                    <li class="breadcrumb-item active">Wallet Transactions</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Wallet Transactions </h4>
                <div class="flex-shrink-0">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTransaction">Deposit</button>
                    
                </div>
            </div><!-- end card header -->

            <div class="card-body table-responsive">
                <!-- Bordered Tables -->
                <table id="buttons-datatables" class="display table table-stripped" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Reference</th>
                            <th scope="col">Amount(₦)</th>
                            <th scope="col">Payment For</th>
                            <th scope="col">Session</th>
                            <th scope="col">Payment Gateway</th>
                            <th scope="col">Payment Type</th>
                            <th scope="col">Status</th>
                            <th scope="col">Payment Date</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php

                        ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($transaction->reference); ?></td>
                            <td>₦<?php echo e(number_format($transaction->amount_payed/100, 2)); ?> </td>
                            <td><?php echo e(!empty($transaction->paymentType)? $transaction->paymentType->type : 'Wallet Deposit'); ?> </td>  
                            <td><?php echo e($transaction->session); ?></td>
                            <td><?php echo e($transaction->payment_method); ?></td>
                            <td><span class="badge badge-soft-<?php echo e($transaction->payment_method == 'Wallet' ? 'danger' : 'success'); ?>"><?php echo e($transaction->payment_method == 'Wallet' ? 'Debit' : 'Credit'); ?></span></td>
                            <td><span class="badge badge-soft-<?php echo e($transaction->status == 1 ? 'success' : 'warning'); ?>"><?php echo e($transaction->status == 1 ? 'success' : 'Pending'); ?></span></td>
                            <td><?php echo e($transaction->status == 1 ? $transaction->updated_at : null); ?> </td>
                            <td>
                        
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div><!-- end card -->
    </div>
    <!-- end col -->
</div>

<div id="addTransaction" class="modal fade" tabindex="-1" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content border-0 overflow-hidden">
            <div class="modal-header p-3">
                <h4 class="card-title mb-0">Deposit into Wallet</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body border-top border-top-dashed">
                <form action="<?php echo e(url('/student/makePayment')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name='programme_id' value="<?php echo e($student->programme->id); ?>">
                    <input type="hidden" name="payment_id" value="0">

                    <div class="mb-3">
                        <label for="amount" class="form-label">Payment Amount<span class="text-danger">*</span></label>
                        <input type='number' name='amount' class="form-control" required placeholder="Enter Deposit Amount">
                    </div>

                    <div class="mb-3">
                        <label for="paymentGateway" class="form-label">Select Payment Gateway<span class="text-danger">*</span></label>
                        <select class="form-select" aria-label="paymentGateway" name="paymentGateway" required onchange="handlePaymentMainMethodChange(event)">
                            <option value= "" selected>Select Payment Gateway</option>
                            <?php if(env('FLUTTERWAVE_STATUS')): ?><option value="Rave">Flutterwave</option><?php endif; ?>
                            <?php if(env('PAYSTACK_STATUS')): ?><option value="Paystack">Paystack</option><?php endif; ?>
                            <?php if(env('BANK_TRANSFER_STATUS')): ?><option value="BankTransfer">Transfer</option><?php endif; ?>
                        </select>
                    </div>

                    <!-- Primary Alert -->
                    <div class="alert alert-primary alert-dismissible alert-additional fade show" role="alert" style="display: none" id="transferInfoMain">
                        <div class="alert-body">
                            <div class="d-flex">
                                <div class="flex-shrink-0 me-3">
                                    <i class="mdi mdi-check-bold fs-16 align-middle"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="alert-heading">Well done !</h5>
                                    <p class="mb-0">Kindly make transfer to the below transaction </p>
                                    <br>
                                    <ul class="list-group">
                                        <li class="list-group-item"><i class="mdi mdi-check-bold align-middle lh-1 me-2"></i><strong>Bank Name:</strong> <?php echo e(env('BANK_NAME')); ?></li>
                                        <li class="list-group-item"><i class="mdi mdi-check-bold align-middle lh-1 me-2"></i><strong>Bank Account Number:</strong> <?php echo e(env('BANK_ACCOUNT_NUMBER')); ?></li>
                                        <li class="list-group-item"><i class="mdi mdi-check-bold align-middle lh-1 me-2"></i><strong>Bank Account Name:</strong> <?php echo e(env('BANK_ACCOUNT_NAME')); ?></li>
                                    </ul>
                                    <br>
                                    <p>Please send proof of payment as an attachment to <?php echo e(env('ACCOUNT_EMAIL')); ?>, including your name, registration number, and purpose of payment. For any inquiries, you can also call <?php echo e(env('ACCOUNT_PHONE')); ?>.</p>
                                </div>
                            </div>
                        </div>
                        <div class="alert-content">
                            <p class="mb-0">NOTE: PLEASE ENSURE TO VERIFY THE TRANSACTION DETAILS PROPERLY. TRANSFER ONLY TO THE ACCOUNT ABOVE. STUDENTS TAKE RESPONSIBILITY FOR ANY MISPLACEMENT OF FUNDS.</p>
                        </div>
                    </div>

                    <div>
                        <button type="submit" id="submit-button-main" class="btn btn-primary">Make payment</button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/koderiang/WebProjects/TAU/tau_portal/resources/views/student/walletTransactions.blade.php ENDPATH**/ ?>