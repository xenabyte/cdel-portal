

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Student Course(s)</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
                    <li class="breadcrumb-item active">Student Course(s)</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->
<?php if(empty($courses)): ?>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <div class="row justify-content-center">
                        <div class="col-lg-9">
                            <h4 class="mt-4 fw-semibold">Fetch Student Course(s)</h4>
                            <p class="text-muted mt-3"></p>
                            <div class="mt-4">
                                <form action="<?php echo e(url('/admin/getStudentCourses')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row g-3">

                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="programme" name="programme_id" aria-label="programme">
                                                    <option value="" selected>--Select--</option>
                                                    <?php $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($programme->id); ?>"><?php echo e($programme->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="department">Programme</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="level" name="level_id" aria-label="level">
                                                    <option value="" selected>--Select--</option>
                                                    <?php $__currentLoopData = $academicLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academicLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($academicLevel->id); ?>"><?php echo e($academicLevel->level); ?> Level</option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="level">Academic Level</label>
                                            </div>
                                        </div>
        
                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="semester" name="semester" aria-label="semester">
                                                    <option value="" selected>--Select--</option>
                                                    <option value="1">First Semester</option>
                                                    <option value="2">Second Semester</option>
                                                </select>
                                                <label for="semester">Semester</label>
                                            </div>
                                        </div>
        

                                        <button type="submit" id="submit-button" class="btn btn-fill btn-primary btn-lg btn-block mb-5">Get Courses</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end card-->
    </div>
    <!--end col-->
</div>
<?php endif; ?>

<?php if(!empty($courses)): ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1"><?php echo e($semester == 1? 'First':'Second'); ?> Semester Course(s) for <?php echo e($academiclevel->level); ?> Level,  <?php echo e($programme->name); ?></h4>
            </div><!-- end card header -->
        </div>
    </div>

            
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="accordion" id="default-accordion-example">
                    <div class="accordion-item shadow">
                        <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed bg-info" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Add Course to be registered by student
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#default-accordion-example">
                            <div class="accordion-body">
                                <form action="<?php echo e(url('/admin/addCourseForStudent')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="level_id" value="<?php echo e($academiclevel->id); ?>">
                                    <input type="hidden" name="programme_id" value="<?php echo e($programme->id); ?>">
                                    <input type="hidden" name="semester" value="<?php echo e($semester); ?>">
                                    <input type="hidden" name="programme" value="<?php echo e($programme); ?>">
                                    <input type="hidden" name="academiclevel" value="<?php echo e($academiclevel); ?>">
                                    <input type="hidden" name="courses" value="<?php echo e($courses); ?>">
                                    <input type="hidden" name="allCourses" value="<?php echo e($allCourses); ?>">
                                    <div class="row g-3">
                
                                        <div class="col-lg-12">
                                            <div class="">
                                                <label>Select Course</label>
                                                <select class="form-select select2" id="selectWithSearch" name="course_id" aria-label="cstatus">
                                                     <option value="" selected>--Select--</option>
                                                    <?php $__currentLoopData = $allCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($allCourse->id); ?>"><?php echo e($allCourse->code); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                
                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <select class="form-select" id="cstatus" name="status" aria-label="cstatus">
                                                    <option value="" selected>--Select--</option>
                                                    <option value="Required">Required</option>
                                                    <option value="Core">Core</option>
                                                    <option value="Elective">Elective</option>
                                                </select>
                                                <label for="cstatus">Status</label>
                                            </div>
                                        </div>
                
                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <input type="text" class="form-control" max="6" name="credit_unit" id="credit_unit">
                                                <label for="semester">Credit Unit</label>
                                            </div>
                                        </div>
                
                                        <button type="submit" id="submit-button" class="btn btn-primary">Add Course</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body table-responsive">
                <!-- Bordered Tables -->
                <table class="table table-stripped table-bordered table-nowrap">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Staff Details</th>
                            <th scope="col">Course Code</th>
                            <th scope="col">Course Title</th>
                            <th scope="col">Course Unit</th>
                            <th scope="col">Status</th>
                            <th scope="col">Level</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $courseManagement =  $course->course->courseManagement->where('academic_session', $pageGlobalData->sessionSetting->academic_session);
                            $assignedCourse = $courseManagement->where('academic_session', $pageGlobalData->sessionSetting->academic_session)->first();
                            $staff = !empty($assignedCourse) ? $assignedCourse->staff->title.' '.$assignedCourse->staff->lastname.' '.$assignedCourse->staff->othernames :null;
                        ?>
                        <tr>
                            <td scope="row"> <?php echo e($loop->iteration); ?></td>
                            <td><?php echo e(!empty($staff)? $staff : null); ?></td>
                            <td><?php echo e($course->course->code); ?></td>
                            <td><?php echo e($course->course->name); ?></td>
                            <td><?php echo e($course->credit_unit); ?> </td>
                            <td><?php echo e($course->status); ?></td>
                            <td><?php echo e($course->level->level); ?></td>
                            <td>
                                <a href="<?php echo e(url('/admin/courseDetail/'.$course->id)); ?>" class="btn btn-lg btn-primary">Course Details</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div><!-- end card -->
    </div>
    <!-- end col -->
</div>
<!-- end row -->
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/koderiang/WebProjects/TAU/tau_portal/resources/views/admin/studentCourses.blade.php ENDPATH**/ ?>