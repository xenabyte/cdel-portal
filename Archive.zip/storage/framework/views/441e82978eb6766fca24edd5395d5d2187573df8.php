<?php
    $totalPoints = $registeredCourses->sum('points');
    $totalCreditUnits = $registeredCourses->sum('course_credit_unit')
?>
<!DOCTYPE html>
<html>
<head>
    <title>Examination Card</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            font-size: 12px;
        }
       
        .header-logo {
            text-align: right;
        }
        .header-logo img {
            width: 25%;
            margin-bottom: 5px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid;
            padding: 2px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .info-column {
            column-count: 2;
            column-gap: 5px;
        }
        @media  print {
            .info-column {
                column-count: 2;
                column-gap: 5px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <table style="width: 100%;">
        <tbody>
            <tr>
                <td style="width: 100%; border: none;">
                    <img src="<?php echo e(env('SCHOOL_LOGO')); ?>" width="40%">
                </td>
            </tr>
        </tbody>
    </table>
    <div class="row" style="margin-top: 2%;">
        <div class="text-center">
            <h1><?php echo e($info->resultSemester == 1? env('FIRST_SEMESTER') : env('SECOND_SEMESTER')); ?>  Examination Result</h1>
            <br>
        </div>
    </div>

    <table style="width: 100%;">
        <tbody>
            <tr>
                <td style="width: 50%; vertical-align: top; text-align: left; border: none; padding-right: 10px;">
                    <div><strong>MATRIC NUMBER:</strong> <?php echo e($info->matric_number); ?></div>
                    <div><strong>APPLICATION NO:</strong> <?php echo e($info->applicant->application_number); ?></div>
                    <div><strong>FULL NAME:</strong> <?php echo e($info->applicant->lastname.' '. $info->applicant->othernames); ?></div>
                    <div><strong>LEVEL:</strong> <?php echo e($info->resultLevel); ?> Level</div>
                </td>
                <td style="width: 50%; vertical-align: top; text-align: left; border: none; padding-left: 10px;">
                    <div><strong>FACULTY:</strong>  <?php echo e($info->faculty->name); ?> </div>
                    <div><strong>DEPARTMENT:</strong> <?php echo e($info->department->name); ?></div>
                    <div><strong>PROGRAMME:</strong> <?php echo e($info->programme->name); ?></div>
                    <div><strong>SESSION:</strong> <?php echo e($info->resultSession); ?></div>
                </td>
            </tr>
        </tbody>
    </table>
    <br>
    <div class="row" style="margin-top: 10px;">
        <div class="col-md-12 text-center">
            <h2>Registered Courses</h2>
        </div>
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>SN</th>
                        <th>Code</th>
                        <th>Course Title</th>
                        <th>Unit</th>
                        <th>Total Score</th>
                        <th>Grade</th>
                        <th>Point</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $registeredCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registeredCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($registeredCourse->course->code); ?></td>
                                <td><?php echo e($registeredCourse->course->name); ?></td>
                                <td><?php echo e($registeredCourse->course_credit_unit); ?></td>
                                <td><?php echo e($registeredCourse->total); ?></td>
                                <td><?php echo e($registeredCourse->grade); ?></td>
                                <td><?php echo e($registeredCourse->points); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><strong>Total</strong></td>
                            <td>
                                <?php echo e($totalCreditUnits); ?>

                            </td>
                            <td></td>
                            <td></td>
                            <td><?php echo e($totalPoints); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-12">
            <h4>G.P.A: <?php echo e(number_format($totalPoints / $totalCreditUnits, 2)); ?></h4>
            <br>
            <h4>C.G.P.A: <?php echo e($info->cgpa); ?></h4>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH /Users/koderiang/WebProjects/TAU/tau_portal/resources/views/pdf/resultCard.blade.php ENDPATH**/ ?>